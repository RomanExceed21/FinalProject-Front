import React, { useState } from 'react'
import Snackbar from '@material-ui/core/Snackbar';
import DeleteVisit from './DeleteVisit'
import EditVisits from './EditVisits'
import trash from '../../img/trash.svg'
import pencil from '../../img/pencil.svg'
import './PacientName.scss'

export default function PacientName({allData, setAllData}) {
  const [modalActiveDel, setModalActiveDel] = useState(false);
  const [modalActiveEdit, setModalActivEdit] = useState('');
  const [activeDelMessage, setActiveDelVessage] = useState(false);

  const [state, setState] = useState({
    open: false,
    message: ''
  });

    const handleClose = () => {
    setState({ ...state, open: false });
  };

  const { open, message } = state;

  const inputDelMessage = () => {
    setState({...state, open: true, message: 'Ошибка авторизации! Проверьте вводимые данные.'});
  }

  return (
    allData.map((value, index) => {
      const { pacientName, doctorName, dateOfVisit, complaintText } = value;
      return (
        <div key = {`data-${index}`} className='total-list'>

          <div className='total-list-block'>
            <p>{pacientName}</p>
          </div>
          <div className='total-list-block'>
            <p>{doctorName}</p>
          </div>
          <div className='total-list-block'>
            <p>{dateOfVisit}</p>
          </div>
          <div className='total-list-block'>
            <p>{complaintText}</p>
          </div>
          <div className='total-list-buttons'>
            <img  
              src={trash} 
              alt=''
              onClick={() => setModalActiveDel(index)} 
            />
            <img  
              src={pencil} 
              alt=''
              onClick={() => setModalActivEdit(index)} 
            />
          </div>  
          {modalActiveDel === index && <DeleteVisit 
            modalActiveDel={modalActiveDel}
            setModalActiveDel={setModalActiveDel}
            setAllData={setAllData}
            allData={allData}
            index={index}
          />}
          {modalActiveEdit === index && <EditVisits 
            modalActiveEdit={modalActiveEdit}
            setModalActivEdit={setModalActivEdit}
            setAllData={setAllData}
            allData={allData}
            value={value}
            index={index}
            // pacientName={pacientName}
            // doctorName={doctorName}
            // dateOfVisit={dateOfVisit}
            // complaintText={complaintText}
          />}
          <Snackbar
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
            open={open}
            onClose={handleClose}
            message={message}
          />
        </div>
      )
    })
    
  )
}
